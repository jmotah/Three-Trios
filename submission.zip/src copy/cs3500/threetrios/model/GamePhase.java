package cs3500.threetrios.model;

/**
 * An enumeration class for the valid phases a game can be in.
 */
public enum GamePhase {
  PLACING,
  BATTLE
}