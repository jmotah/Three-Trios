package cs3500.threetrios.model.grid;

/**
 * An enumeration class for the valid types a cell can be.
 */
public enum CellType {
  HOLE,
  CARD_CELL,
  PLAYER_CELL
}